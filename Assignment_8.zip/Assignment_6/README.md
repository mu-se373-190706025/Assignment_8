# Assignment_6![Ekran görüntüsü 2022-04-06 115510](https://user-images.githubusercontent.com/101142514/161937487-e8bfd7cb-fb99-4fcc-a09e-4388ba3b5546.png)
![Ekran görüntüsü 2022-04-06 115550](https://user-images.githubusercontent.com/101142514/161937499-f2b70707-f5e4-4ade-a830-5541ec29fcfd.png)
![Ekran görüntüsü 2022-04-06 115611](https://user-images.githubusercontent.com/101142514/161937505-725d3f05-bc5c-4929-a534-6b4335989d57.png)
