package com.meliskara.assignment_6

object URLs {
    private val ROOT_URL = "http://192.168.1.108:8080/androidphpmysql/registrationapi.php?apicall="
    val URL_REGISTER = ROOT_URL + "signup"
    val URL_LOGIN = ROOT_URL + "login"
    val URL_DELETE = ROOT_URL + "delete"
}